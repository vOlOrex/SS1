'use client'

import { useMemo, useState } from 'react'
import { ArrowDownToLine, ArrowUpRight, Check, ChevronDown, Clock3, Command, Inbox, MessageSquareText, Search, Send, ShieldCheck, Sparkles, Trash2, Users } from 'lucide-react'

type HistoryEntry = { id: string; username: string; message: string; createdAt: string; status: 'queued' | 'retrieved' }

function initials(username: string) {
  return username.slice(0, 2).toUpperCase()
}

export function MessageDashboard() {
  const [username, setUsername] = useState('')
  const [message, setMessage] = useState('')
  const [history, setHistory] = useState<HistoryEntry[]>([])
  const [search, setSearch] = useState('')
  const [sending, setSending] = useState(false)
  const [notice, setNotice] = useState('')
  const [error, setError] = useState('')

  const filtered = useMemo(() => history.filter((entry) =>
    `${entry.username} ${entry.message}`.toLowerCase().includes(search.toLowerCase()),
  ), [history, search])
  const queuedCount = history.filter((entry) => entry.status === 'queued').length
  const recipientCount = new Set(history.map((entry) => entry.username)).size

  async function sendMessage(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault()
    setError('')
    setNotice('')
    const trimmedUsername = username.trim()
    const trimmedMessage = message.trim()
    if (!trimmedUsername || !trimmedMessage) {
      setError('Add a username and a message before sending.')
      return
    }
    setSending(true)
    try {
      const response = await fetch('/api/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: trimmedUsername, message: trimmedMessage }),
      })
      const result = await response.json()
      if (!response.ok) throw new Error(result.error || 'Message could not be queued.')
      setHistory((current) => [result.message as HistoryEntry, ...current])
      setUsername('')
      setMessage('')
      setNotice(`Message queued for @${trimmedUsername}`)
    } catch (sendError) {
      setError(sendError instanceof Error ? sendError.message : 'Message could not be queued.')
    } finally {
      setSending(false)
    }
  }

  async function retrieve(entry: HistoryEntry) {
    setError('')
    setNotice('')
    try {
      const response = await fetch(`/api/messages?username=${encodeURIComponent(entry.username)}`)
      const result = await response.json()
      if (!response.ok) throw new Error(result.error || 'Message could not be retrieved.')
      if (!result.message) {
        setNotice(`No queued messages for @${entry.username}`)
      } else {
        setHistory((current) => {
          const index = current.findIndex((item) => item.id === result.message.id)
          if (index < 0) return current
          return current.map((item, itemIndex) => itemIndex === index ? { ...item, status: 'retrieved' } : item)
        })
        setNotice(`Retrieved the next message for @${entry.username}`)
      }
    } catch (retrieveError) {
      setError(retrieveError instanceof Error ? retrieveError.message : 'Message could not be retrieved.')
    }
  }

  return (
    <main className="app-shell">
      <aside className="sidebar">
        <a className="brand" href="#home" aria-label="Relay home">
          <span className="brand-mark"><MessageSquareText size={19} strokeWidth={2.4} /></span>
          <span>relay<span className="brand-period">.</span></span>
        </a>
        <div className="workspace-picker">
          <span className="workspace-avatar">W</span>
          <span className="workspace-copy"><strong>Workspace</strong><small>Free plan</small></span>
          <ChevronDown size={15} className="muted-icon" />
        </div>
        <p className="nav-label">WORKSPACE</p>
        <nav className="nav-list" aria-label="Main navigation">
          <a className="nav-item active" href="#overview"><Command size={17} /> Overview</a>
          <a className="nav-item" href="#messages"><Inbox size={17} /> Messages <span className="nav-count">{queuedCount}</span></a>
          <a className="nav-item" href="#recipients"><Users size={17} /> Recipients</a>
        </nav>
        <div className="sidebar-bottom">
          <div className="plan-card"><span className="plan-icon"><Sparkles size={15} /></span><strong>Simple by design</strong><p>Messages live in temporary memory and clear when retrieved.</p></div>
          <div className="profile-row"><span className="profile-avatar">JD</span><span className="profile-copy"><strong>Jamie Davis</strong><small>Admin</small></span><ChevronDown size={15} className="muted-icon" /></div>
        </div>
      </aside>

      <section className="main-panel" id="overview">
        <header className="topbar">
          <div className="breadcrumb"><span>Workspace</span><span className="crumb-slash">/</span><strong>Overview</strong></div>
          <div className="topbar-right"><span className="live-indicator"><i /> System operational</span><span className="topbar-divider" /><button className="icon-button" aria-label="Search" onClick={() => document.getElementById('history-search')?.focus()}><Search size={17} /></button><span className="top-avatar">JD</span></div>
        </header>

        <div className="content-wrap">
          <div className="page-heading"><div><div className="eyebrow"><span className="eyebrow-line" /> YOUR MESSAGING WORKSPACE</div><h1>Good morning, Jamie <span className="wave">✳</span></h1><p className="heading-subtitle">A clear view of your messages, all in one place.</p></div><div className="date-pill"><Clock3 size={15} /> Live overview</div></div>

          <section className="stats-grid" aria-label="Message statistics">
            <article className="stat-card"><div className="stat-top"><span>Messages queued</span><span className="stat-icon blue"><Inbox size={16} /></span></div><div className="stat-value">{queuedCount.toString().padStart(2, '0')}</div><div className="stat-foot"><span className="stat-dot blue-dot" /> Ready to retrieve</div></article>
            <article className="stat-card"><div className="stat-top"><span>Total sent</span><span className="stat-icon violet"><ArrowUpRight size={16} /></span></div><div className="stat-value">{history.length.toString().padStart(2, '0')}</div><div className="stat-foot">Across this session</div></article>
            <article className="stat-card"><div className="stat-top"><span>Recipients</span><span className="stat-icon green"><Users size={16} /></span></div><div className="stat-value">{recipientCount.toString().padStart(2, '0')}</div><div className="stat-foot">Unique usernames</div></article>
            <article className="stat-card status-stat"><div className="stat-top"><span>Service status</span><span className="stat-icon green"><ShieldCheck size={16} /></span></div><div className="status-value"><span className="status-pulse" /> Operational</div><div className="stat-foot">In-memory message queue</div></article>
          </section>

          <div className="dashboard-grid">
            <section className="panel compose-panel" aria-labelledby="compose-title">
              <div className="panel-heading"><div><span className="panel-kicker">QUICK ACTION</span><h2 id="compose-title">Send a message</h2><p>Deliver a text payload to a username.</p></div><span className="compose-heading-icon"><Send size={18} /></span></div>
              <form onSubmit={sendMessage} className="compose-form">
                <label htmlFor="recipient">Recipient username</label>
                <div className="username-input"><span>@</span><input id="recipient" autoComplete="off" placeholder="e.g. alexmorgan" maxLength={64} value={username} onChange={(event) => setUsername(event.target.value)} /></div>
                <div className="message-label-row"><label htmlFor="message">Your message</label><span>{message.length}/2000</span></div>
                <textarea id="message" placeholder="Write something thoughtful..." maxLength={2000} rows={4} value={message} onChange={(event) => setMessage(event.target.value)} />
                {error && <p className="form-feedback error" role="alert">{error}</p>}
                {notice && <p className="form-feedback success" role="status"><Check size={14} />{notice}</p>}
                <div className="form-footer"><span><ShieldCheck size={14} /> Stored temporarily</span><button className="send-button" type="submit" disabled={sending}>{sending ? 'Sending…' : 'Send message'} <ArrowUpRight size={15} /></button></div>
              </form>
              <div className="privacy-note"><span className="privacy-dot" /> Messages are held in memory until retrieved.</div>
            </section>

            <section className="panel activity-panel">
              <div className="panel-heading activity-heading"><div><span className="panel-kicker">AT A GLANCE</span><h2>Queue activity</h2><p>A snapshot of your message queue.</p></div></div>
              <div className="activity-summary"><div className="activity-number">{queuedCount.toString().padStart(2, '0')}</div><div><strong>waiting to be picked up</strong><span>Messages clear from memory on retrieval.</span></div></div>
              <div className="activity-divider" />
              <div className="activity-row"><span className="activity-symbol"><Inbox size={15} /></span><span>Pending messages</span><strong>{queuedCount}</strong></div>
              <div className="activity-row"><span className="activity-symbol"><Check size={15} /></span><span>Retrieved this session</span><strong>{history.filter((item) => item.status === 'retrieved').length}</strong></div>
              <div className="activity-note"><span className="note-indicator" /><span>Queue data is temporary and may reset when the server restarts.</span></div>
            </section>
          </div>

          <section className="panel history-panel" id="messages">
            <div className="history-header"><div><span className="panel-kicker">MESSAGE LOG</span><h2>Recent messages <span className="history-total">{history.length}</span></h2><p>Every message sent in this session.</p></div><div className="history-controls"><label className="search-box"><Search size={15} /><input id="history-search" type="search" placeholder="Search messages..." value={search} onChange={(event) => setSearch(event.target.value)} /></label><button className="filter-button" onClick={() => setSearch('')} aria-label="Clear search"><Trash2 size={14} /><span>Clear filter</span></button></div></div>
            <div className="table-scroll"><table><thead><tr><th>RECIPIENT</th><th>MESSAGE</th><th>TIME</th><th>STATUS</th><th><span className="sr-only">Actions</span></th></tr></thead><tbody>
              {filtered.length === 0 ? <tr><td colSpan={5}><div className="empty-state"><span className="empty-icon"><Inbox size={19} /></span><strong>{search ? 'No matching messages' : 'Your message log is ready'}</strong><span>{search ? 'Try a different username or message.' : 'Messages you send will appear here.'}</span></div></td></tr> : filtered.map((entry) => <tr key={entry.id}><td><div className="recipient-cell"><span className="recipient-avatar">{initials(entry.username)}</span><span className="recipient-name">@{entry.username}</span></div></td><td><span className="message-preview" title={entry.message}>{entry.message}</span></td><td><span className="time-cell">{new Date(entry.createdAt).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })}</span></td><td><span className={`status-badge ${entry.status}`}><i />{entry.status === 'queued' ? 'Queued' : 'Retrieved'}</span></td><td className="action-cell">{entry.status === 'queued' && <button className="retrieve-button" onClick={() => void retrieve(entry)} title={`Retrieve next message for ${entry.username}`}><ArrowDownToLine size={14} /><span>Retrieve</span></button>}</td></tr>)}
            </tbody></table></div>
            <div className="table-footer"><span>Showing <strong>{filtered.length}</strong> of <strong>{history.length}</strong> messages</span><span className="table-live"><i /> Updates in real time</span></div>
          </section>
          <footer className="page-footer"><span>© 2026 Relay. A little more clarity, every day.</span><span><span className="footer-status" /> All systems normal</span></footer>
        </div>
      </section>
    </main>
  )
}
