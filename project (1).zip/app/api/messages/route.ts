import { NextRequest, NextResponse } from 'next/server'

export const runtime = 'nodejs'

type MessageRecord = { id: string; username: string; message: string; createdAt: string; status: 'queued' | 'retrieved' }
type MessageStore = { queue: Map<string, MessageRecord[]>; history: MessageRecord[] }

const globalStore = globalThis as typeof globalThis & { relayMessageStore?: MessageStore }
const store = globalStore.relayMessageStore ??= { queue: new Map<string, MessageRecord[]>(), history: [] }

export async function POST(request: NextRequest) {
  let payload: unknown
  try {
    payload = await request.json()
  } catch {
    return NextResponse.json({ error: 'Request body must be valid JSON.' }, { status: 400 })
  }
  if (!payload || typeof payload !== 'object') {
    return NextResponse.json({ error: 'Request body must include username and message.' }, { status: 400 })
  }
  const { username, message } = payload as Record<string, unknown>
  if (typeof username !== 'string' || !username.trim() || username.trim().length > 64) {
    return NextResponse.json({ error: 'Username must be between 1 and 64 characters.' }, { status: 400 })
  }
  if (typeof message !== 'string' || !message.trim() || message.length > 2000) {
    return NextResponse.json({ error: 'Message must be between 1 and 2000 characters.' }, { status: 400 })
  }

  const record: MessageRecord = {
    id: crypto.randomUUID(),
    username: username.trim().replace(/^@/, ''),
    message: message.trim(),
    createdAt: new Date().toISOString(),
    status: 'queued',
  }
  if (!record.username) return NextResponse.json({ error: 'Username is required.' }, { status: 400 })
  const queue = store.queue.get(record.username) ?? []
  queue.push(record)
  store.queue.set(record.username, queue)
  store.history.unshift(record)
  return NextResponse.json({ ok: true, message: record }, { status: 201 })
}

export async function GET(request: NextRequest) {
  const username = request.nextUrl.searchParams.get('username')?.trim().replace(/^@/, '')
  if (!username || username.length > 64) {
    return NextResponse.json({ error: 'A username query parameter (1–64 characters) is required.' }, { status: 400 })
  }
  const queue = store.queue.get(username) ?? []
  const record = queue.shift()
  if (queue.length === 0) store.queue.delete(username)
  else store.queue.set(username, queue)
  if (record) {
    record.status = 'retrieved'
  }
  return NextResponse.json({ ok: true, username, message: record ?? null })
}
