import { MessageDashboard } from '@/components/message-dashboard'

export default function Page() {
  return <MessageDashboard />
}
